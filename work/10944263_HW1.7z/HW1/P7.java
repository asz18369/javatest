public class P7{
    public static void main(String args[]){
        System.out.print("East or west");
        System.out.println(" home is best");
    }
}