import java.util.Scanner;
public class P21{
    public static void main(String args[])
    {
    Scanner scn=new Scanner(System.in);
    int a;
    int b;

    System.out.print("A=");
    a=scn.nextInt();
    System.out.print("B=");
    b=scn.nextInt();

    System.out.print("A+B="+(a+b));
    }
}