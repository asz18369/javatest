///////////////////////////////////
//
//   ���ܽ�
//   10944263
//   112/2/20
//   HelloWorld program
//
///////////////////////////////////

public class Hi{
    public static void main(String args[])
    {
	System.out.println("Hello "+args[1]+" , "+args[0]+" Welcome to Java!");
    }
}