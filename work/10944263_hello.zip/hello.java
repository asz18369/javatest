public class hello
{
  public static void main(String[] aru)
  {
    System.out.println("hello world");
  }
}